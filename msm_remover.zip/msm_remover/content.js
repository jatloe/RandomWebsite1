function checkLoaded() {
	if (document.readyState === "complete" || document.readyState === "interactive") {
		doStuff();
	}
}
setInterval(checkLoaded,50);

function doStuff() {
	const stuff = document.querySelectorAll(".cmty-no-phone");
	for (var i = 0; i < stuff.length; i++) {
		try {
			if (stuff[i].style.color == "rgb(255, 153, 0)") {
				stuff[i].parentNode.parentNode.remove();
			}
		} catch (error) {
			//hi
		}
	}
}